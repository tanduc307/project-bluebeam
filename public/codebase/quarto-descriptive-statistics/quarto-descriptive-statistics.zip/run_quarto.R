system("quarto preview quarto-descriptive-statistics.qmd")

